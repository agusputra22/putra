<?php

namespace frontend\models;

use Yii;
use common\models\User as User1;

class User extends User1{

}
?>